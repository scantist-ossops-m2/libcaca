package Term::Kaka::Bitmap;

use base 'Term::Caca::Bitmap';

1;
