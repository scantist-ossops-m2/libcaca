package Term::Caca::Sprite;


1;

