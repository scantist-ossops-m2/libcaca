package Term::Kaka::Sprite;

use base 'Term::Caca::Sprite';

1;
