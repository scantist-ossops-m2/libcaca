#ifndef __CACA_DITHER_H__
#define __CACA_DITHER_H__

#include <ruby.h>

extern VALUE cDither;
extern void Init_caca_dither(VALUE);

#endif
