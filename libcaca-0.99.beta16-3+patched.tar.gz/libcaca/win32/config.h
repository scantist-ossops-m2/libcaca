/* $Id$ */

#define ALLOCCONSOLE_IN_WINDOWS_H 1
/* #undef HAVE_CONIO_H */
/* #undef HAVE_CURSES_H */
/* #undef HAVE_ENDIAN_H */
#define HAVE_ERRNO_H 1
#define HAVE_GETENV 1
/* #undef HAVE_GETTIMEOFDAY */
/* #undef HAVE_IMLIB2_H */
/* #undef HAVE_INTTYPES_H */
/* #undef HAVE_IOCTL */
#define HAVE_MEMORY_H 1
/* #undef HAVE_NCURSES_H */
#define HAVE_PUTENV 1
/* #undef HAVE_RESIZETERM */
/* #undef HAVE_RESIZE_TERM */
/* #undef HAVE_SIGNAL */
/* #undef HAVE_SIGNAL_H */
/* #undef HAVE_SLANG_H */
/* #undef HAVE_SLANG_SLANG_H */
#define HAVE_SLEEP 1
/* #undef HAVE_STDINT_H */
#define HAVE_STDLIB_H 1
/* #undef HAVE_STRCASECMP */
#define HAVE_STRINGS_H 1
#define HAVE_STRING_H 1
/* #undef HAVE_SYS_IOCTL_H */
#define HAVE_SYS_STAT_H 1
/* #undef HAVE_SYS_TIME_H */
#define HAVE_SYS_TYPES_H 1
/* #undef HAVE_UNISTD_H */
/* #undef HAVE_USLEEP */
/* #undef HAVE_VSNPRINTF */
#define HAVE_SNPRINTF 1
#define HAVE_WINDOWS_H 1
/* #undef HAVE_X11_XKBLIB_H */
/* #undef NO_MINUS_C_MINUS_O */
#define PACKAGE_BUGREPORT ""
#define PACKAGE_NAME "libcaca"
#define PACKAGE_STRING ""
#define PACKAGE_TARNAME ""
#define PACKAGE_VERSION "0.99.beta16"
/* #undef RETSIGTYPE */
/* #undef SCREENUPDATE_IN_PC_H */
#define STDC_HEADERS 1
/* #undef USE_CONIO */
/* #undef USE_NCURSES */
/* #undef USE_SLANG */
#define USE_WIN32 1
/* #undef USE_X11 */
/* #undef const */
#ifndef __cplusplus
#define inline __inline
#endif
#define strcasecmp stricmp
#define snprintf _snprintf
