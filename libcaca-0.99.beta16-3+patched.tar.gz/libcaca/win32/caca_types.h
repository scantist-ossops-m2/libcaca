#define CACA_TYPES 3
#include "../caca/caca_types.h.in"